# project-release-review

DSH 0.1.1-rc.2 发布审查练习插件。安装包贡献一个文件系统 Skill 来源和一个简短 System Prompt 段，不替换完整系统提示词。

在此目录运行 `npm pack`，随后在隔离环境中执行 `dsh plugin --profile web add /绝对路径/生成的安装包.tgz`。启动 Web，选择练习项目目录，要求发布前审查。检查会话中是否调用了 `skill`，其参数应为 `project-release-review`。

本插件不发布 npm 包。默认只读；命令执行、文件修改与发布权限是不同的事，Skill 文本不是强制权限控制。
