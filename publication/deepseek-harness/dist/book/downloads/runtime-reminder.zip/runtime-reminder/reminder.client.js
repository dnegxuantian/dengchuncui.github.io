return {
  inject: ['timer'],
  apply(ctx) {
    const slots = ctx.get('slots');
    if (slots === undefined) throw new Error('当前页面没有 slots 服务');
    const durationSeconds = 90;
    const reminderText = '检查一下当前任务，别忘了回来确认结果';
    const h = React.createElement;
    styles.insert(`
      .book-reminder { position:fixed; top:64px; right:24px; width:300px;
        padding:20px; border:1px solid #bfd5d0; border-radius:16px;
        background:#f5faf8; color:#163d35; box-shadow:0 8px 28px #102c2820;
        font:14px/1.5 system-ui,sans-serif; pointer-events:auto; }
      .book-reminder button { border:1px solid #b8cec7; border-radius:8px;
        background:white; color:#163d35; padding:7px 12px; cursor:pointer; }
      .book-reminder .clock { font-size:42px; line-height:1.3;
        font-variant-numeric:tabular-nums; margin:8px 0; }
      .book-reminder .actions { display:flex; gap:8px; margin-top:14px; }
      .book-reminder[data-done="true"] { border-color:#d2ab58; background:#fff8e9; }
    `);
    function Reminder() {
      const [remaining, setRemaining] = React.useState(durationSeconds * 1000);
      const [deadline, setDeadline] = React.useState(null);
      const [compact, setCompact] = React.useState(false);
      React.useEffect(() => {
        if (deadline === null) return;
        const dispose = ctx.interval(() => {
          const next = Math.max(0, deadline - Date.now());
          setRemaining(next);
          if (next === 0) setDeadline(null);
        }, 250);
        return dispose;
      }, [deadline]);
      const done = remaining === 0;
      const seconds = Math.ceil(remaining / 1000);
      const display = String(Math.floor(seconds / 60)).padStart(2, '0')
        + ':' + String(seconds % 60).padStart(2, '0');
      function toggle() {
        if (deadline !== null) {
          setRemaining(Math.max(0, deadline - Date.now()));
          setDeadline(null);
        } else if (!done) setDeadline(Date.now() + remaining);
      }
      function reset() {
        setDeadline(null);
        setRemaining(durationSeconds * 1000);
      }
      return h('section', {className:'book-reminder', 'aria-label':'临时任务提醒', 'data-done':done},
        h('div', {style:{display:'flex',justifyContent:'space-between',alignItems:'center'}},
          h('strong', null, done ? '时间到了' : '任务提醒'),
          h('button', {onClick:() => setCompact(!compact)}, compact ? '展开' : '收起')),
        h('div', {className:'clock', role:'timer'}, display),
        !compact && h('p', null, reminderText),
        h('div', {className:'actions'},
          h('button', {onClick:toggle, disabled:done}, deadline !== null ? '暂停' : '开始 / 继续'),
          h('button', {onClick:reset}, '重置')));
    }
    slots.inject('shell.overlay', () => slots.register(
      {name:'shell.overlay', id:'book-task-reminder', order:30, label:'任务提醒'},
      () => h(Reminder)));
  },
};
