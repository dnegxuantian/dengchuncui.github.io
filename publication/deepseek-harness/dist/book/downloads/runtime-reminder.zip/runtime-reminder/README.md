# DSH 临时任务提醒

这是动态 Cordis 插件的 Client 代码，不是 npm 插件包。使用官方 DSH 0.1.1-rc.2 的 Web 界面和“创造模式”。`reminder.client.js` 是 90 秒版本，`reminder-v2.client.js` 只改为 15 秒和另一句提醒。

## 运行

1. 解压本目录；启动已安装的 DSH Web，在界面选择本目录为工作区。不要执行 `node reminder.client.js`：文件返回的插件对象需要由 DSH 运行，不能作为独立脚本启动。
2. 在发送第一条消息前选择“创造模式”。先让模型加载 `cordis-plugin-development` Skill，实际调用 `cordis_inspect_list`，再查询 Client Builtin、timer、slots 和 `shell.overlay` 的接口。若该版本没有创造模式或这些工具，先核对 DSH 版本，不要改装原厂 preset。
3. 发消息：“读取 reminder.client.js 全文，把原文作为 code.client，调用 cordis_define 创建 idPrefix 为 remind 的新插件，名称为任务提醒。现在只定义，不运行。”
4. 记下实际返回的 pluginId、packageId。以下用 remind-1、pkg-1 演示，你的编号可能不同。
5. 发消息：“实际调用 cordis_run，pluginId=remind-1，packageId=pkg-1，mode=run。等待审批时结束本轮。”点击左下角 Cordis Plugin，在对应条目中选择“仅允许此版本”。
6. 页面右上角出现 01:30 的提醒。点击“开始 / 继续”开始计时，“暂停”保留剩余时间，“重置”回到初始时长但不自动开始，“收起”只隐藏文案，计时不暂停。

不要把模型回答“已运行”当作成功：应看到真实 cordis_run 工具行、批准后的运行状态和提醒卡片。

## 更新同一个插件

发消息：“@remind-1 先用 cordis_inspect_self 读取当前版本，再读取 reminder-v2.client.js 全文，以 existing 模式定义同一插件的新 Package。只定义不运行。”定义本身不会替换页面组件。记下新的 packageId 后请求 `cordis_run`，mode 为 `update`，并批准新版本。右上角变为 00:15 和新文案。

更新会重新创建组件，原来的倒计时进度不会迁移。本例从暂停的初始状态开始，点击开始后到零显示“时间到了”。这是页面提醒，不会检测测试是否真的完成。

## 停止与重新运行

请求模型实际调用 `cordis_stop`，参数为当前 pluginId。组件与其样式会移除，定义及代码版本保留。重新运行最近成功版本使用 `cordis_run` 的 `run` 模式。不要把“停止”写成 `cordis_undefine`，后者会删除整个插件及其版本。

本例不持久化倒计时，也不提供系统通知。页面关闭后没有后台浏览器提醒；DSH 进程重启后动态定义丢失，但本目录的源码文件仍在，可重新定义。不适合承担必须准时执行的生产调度。

## 自己修改

`durationSeconds` 决定初始秒数，`reminderText` 决定提示语。正文讲解 `inject: ['timer']`、`ctx.interval` 清理函数、React 状态、Slot 挂载和不可变版本的关系。保留这些生命周期处理，不要直接换成不受管理的全局定时器。

`browser.patch.yml` 仅供本书隔离实验使用：改用浏览器目录选择器，并设定模型参数；不属于提醒代码本身，也不需要为使用提醒而覆盖你的日常配置。
